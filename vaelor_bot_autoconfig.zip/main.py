import asyncio
import json
import os
import sys
from pathlib import Path

CONFIG = Path("config.json")

def setup():
    print("\n=== VAELOR — первый запуск ===\n")
    print("Секреты сохраняются только локально в Codespace.")
    print("Не вставляй токен в Git и не отправляй его в чат.\n")

    token = input("1) Введи НОВЫЙ Telegram Bot Token: ").strip()
    while not token:
        token = input("Токен не может быть пустым. Введи токен: ").strip()

    owner = input("2) Введи Telegram ID владельца (можно Enter для автоопределения): ").strip()
    channel = input("3) Канал для обязательной подписки [@legendaryfp]: ").strip() or "@legendaryfp"

    data = {
        "bot_token": token,
        "owner_telegram_id": owner,
        "required_channel": channel
    }
    CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\nНастройки сохранены. Перезапускаю...\n")
    return data

def load_config():
    if not CONFIG.exists():
        return setup()
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        if not data.get("bot_token"):
            return setup()
        return data
    except Exception:
        return setup()

async def run():
    cfg = load_config()

    from aiogram import Bot, Dispatcher, Router
    from aiogram.filters import CommandStart
    from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
    from aiogram.exceptions import TelegramBadRequest

    bot = Bot(cfg["bot_token"])
    router = Router()

    channel = cfg.get("required_channel", "@legendaryfp")
    owner_id = str(cfg.get("owner_telegram_id", "")).strip()

    def menu():
        return InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🛒 Магазин", callback_data="shop"),
             InlineKeyboardButton(text="⚙️ Автоматизация", callback_data="automation")],
            [InlineKeyboardButton(text="📦 Лоты", callback_data="lots"),
             InlineKeyboardButton(text="🧩 Плагины", callback_data="plugins")],
            [InlineKeyboardButton(text="👤 Профиль", callback_data="profile"),
             InlineKeyboardButton(text="🎁 Рефералы", callback_data="referrals")],
            [InlineKeyboardButton(text="💬 Поддержка", callback_data="support")]
        ])

    async def subscribed(user_id: int):
        try:
            m = await bot.get_chat_member(channel, user_id)
            return m.status in {"creator", "administrator", "member"} or (
                m.status == "restricted" and getattr(m, "is_member", False)
            )
        except TelegramBadRequest:
            return False

    @router.message(CommandStart())
    async def start(message: Message):
        if not await subscribed(message.from_user.id):
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📢 Подписаться", url="https://t.me/legendaryfp")],
                [InlineKeyboardButton(text="🔄 Я подписался", callback_data="check")]
            ])
            await message.answer(
                "🔐 <b>Доступ закрыт</b>\n\n"
                "Сначала подпишись на @legendaryfp, затем нажми «Я подписался».",
                reply_markup=kb, parse_mode="HTML"
            )
            return

        # Безопасное поведение: VLD задаётся через конфиг, а не «кто первый нажал /start».
        role = "VLD" if owner_id and str(message.from_user.id) == owner_id else "SELLER"
        await message.answer(
            f"🚀 <b>VAELOR</b>\n\n"
            f"Привет, {message.from_user.full_name}!\n"
            f"Роль: <b>{role}</b>\n\n"
            "Выбери раздел:",
            reply_markup=menu(), parse_mode="HTML"
        )

    @router.callback_query()
    async def callbacks(call: CallbackQuery):
        if call.data == "check":
            await call.answer("Проверяю…")
            if await subscribed(call.from_user.id):
                await call.message.edit_text("✅ Подписка подтверждена. Нажми /start.")
            else:
                await call.answer("Подписка пока не найдена.", show_alert=True)
            return

        text = {
            "shop": "🛒 <b>Магазин</b>\nVIP • плагины • подарки • история покупок",
            "automation": "⚙️ <b>Автоматизация</b>\nПланировщик • мониторинг • уведомления • задачи",
            "lots": "📦 <b>Лоты</b>\nСоздание • редактирование • массовые операции",
            "plugins": "🧩 <b>Плагины</b>\nКаталог • установка • версии • отзывы",
            "profile": "👤 <b>Профиль</b>\nБаланс • роль • настройки",
            "referrals": "🎁 <b>Рефералы</b>\nСсылка • активированные пользователи • награды",
            "support": "💬 <b>Поддержка</b>\nОбращения • AI-помощник • история"
        }.get(call.data, "Раздел готовится.")
        await call.message.answer(text, parse_mode="HTML")
        await call.answer()

    dp = Dispatcher()
    dp.include_router(router)
    print("VAELOR BOT STARTED")
    print("Нажми Ctrl+C для остановки.")
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\nОстановлено.")
